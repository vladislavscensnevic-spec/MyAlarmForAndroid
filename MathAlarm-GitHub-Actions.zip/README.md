# Math Alarm

A minimal white Android alarm app starter project built with Kotlin and Jetpack Compose.

## Open
1. Install Android Studio
2. Open this folder as a project
3. Let Gradle sync
4. Run on a real Android device

## Important limitations in this starter
- This is source code, not a prebuilt APK
- Alarm volume is currently saved as a setting but Android's system alarm stream controls actual output volume
- Shake is currently represented by a manual counter; hardware sensor integration is a next implementation step
- Challenge sequence and code tasks are basic prototypes
- Exact alarm permission and notification permission must be granted
- Some manufacturers apply battery restrictions; allow the app to run in the background

## Build APK
In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

The APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.


## Cloud APK build with GitHub Actions
This project includes `.github/workflows/build-apk.yml`.
Upload the project contents to a GitHub repository. The workflow runs on pushes to `main`
and can also be started manually from the repository's Actions tab.
When the run succeeds, open the run, scroll to Artifacts, and download
`MathAlarm-debug-apk`. Extract the ZIP to get `app-debug.apk`.
