package com.kotik.mathalarm

import android.content.Context

object AlarmPrefs {
    private const val FILE = "alarm_settings"
    private fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun save(context: Context, hour: Int, minute: Int, volume: Int, count: Int, difficulty: Int,
             shake: Boolean, math: Boolean, code: Boolean, puzzle: Boolean, enabled: Boolean) {
        prefs(context).edit()
            .putInt("hour", hour).putInt("minute", minute).putInt("volume", volume)
            .putInt("count", count).putInt("difficulty", difficulty)
            .putBoolean("shake", shake).putBoolean("math", math).putBoolean("code", code)
            .putBoolean("puzzle", puzzle).putBoolean("enabled", enabled).apply()
    }

    fun int(context: Context, key: String, default: Int) = prefs(context).getInt(key, default)
    fun bool(context: Context, key: String, default: Boolean) = prefs(context).getBoolean(key, default)
}
