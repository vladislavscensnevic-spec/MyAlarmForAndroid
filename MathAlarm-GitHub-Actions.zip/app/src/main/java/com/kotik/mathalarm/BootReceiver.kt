package com.kotik.mathalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (AlarmPrefs.bool(context, "enabled", false)) AlarmScheduler.schedule(context)
    }
}
