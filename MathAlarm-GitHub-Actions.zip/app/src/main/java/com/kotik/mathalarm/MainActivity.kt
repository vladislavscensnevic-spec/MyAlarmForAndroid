package com.kotik.mathalarm

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Ink = Color(0xFF111111)
private val Muted = Color(0xFF777777)
private val Line = Color(0xFFE5E5E5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Ink, onPrimary = Color.White, background = Color.White,
                surface = Color.White, onSurface = Ink
            )) {
                Surface(Modifier.fillMaxSize(), color = Color.White) {
                    var ringing by remember { mutableStateOf(intent.getBooleanExtra("ringing", false)) }
                    if (ringing) RingingScreen(
                        onDone = {
                            stopService(Intent(this, AlarmService::class.java))
                            ringing = false
                        }
                    ) else HomeScreen(
                        context = this,
                        onTest = {
                            val i = Intent(this, AlarmService::class.java)
                            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                            ringing = true
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(context: MainActivity, onTest: () -> Unit) {
    var hour by remember { mutableIntStateOf(AlarmPrefs.int(context, "hour", 7)) }
    var minute by remember { mutableIntStateOf(AlarmPrefs.int(context, "minute", 30)) }
    var volume by remember { mutableFloatStateOf(AlarmPrefs.int(context, "volume", 80).toFloat()) }
    var count by remember { mutableIntStateOf(AlarmPrefs.int(context, "count", 5)) }
    var difficulty by remember { mutableIntStateOf(AlarmPrefs.int(context, "difficulty", 3)) }
    var enabled by remember { mutableStateOf(AlarmPrefs.bool(context, "enabled", false)) }
    var shake by remember { mutableStateOf(AlarmPrefs.bool(context, "shake", false)) }
    var math by remember { mutableStateOf(AlarmPrefs.bool(context, "math", true)) }
    var code by remember { mutableStateOf(AlarmPrefs.bool(context, "code", false)) }
    var puzzle by remember { mutableStateOf(AlarmPrefs.bool(context, "puzzle", false)) }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 28.dp)) {
        Text("alarm", fontSize = 25.sp, fontWeight = FontWeight.Medium, color = Ink)
        Spacer(Modifier.height(46.dp))
        Text("%02d:%02d".format(hour, minute), fontSize = 58.sp, fontWeight = FontWeight.Light, color = Ink)
        Text(if (enabled) "Alarm enabled" else "Alarm disabled", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(28.dp))
        DividerLine()
        SectionTitle("TIME")
        Row(verticalAlignment = Alignment.CenterVertically) {
            NumberField(hour.toString(), { hour = (it.toIntOrNull() ?: hour).coerceIn(0, 23) }, "Hour")
            Text(":", fontSize = 24.sp, color = Muted, modifier = Modifier.padding(horizontal = 12.dp))
            NumberField(minute.toString(), { minute = (it.toIntOrNull() ?: minute).coerceIn(0, 59) }, "Minute")
        }
        Spacer(Modifier.height(24.dp))
        DividerLine()
        SectionTitle("CHALLENGES")
        CheckRow("Shake", shake) { shake = it }
        CheckRow("Math problems", math) { math = it }
        CheckRow("Random code", code) { code = it }
        CheckRow("Memory puzzle", puzzle) { puzzle = it }
        Spacer(Modifier.height(12.dp))
        SettingSlider("Number of tasks", count.toFloat(), 1f, 20f, { count = it.toInt() }, "$count")
        SettingSlider("Difficulty", difficulty.toFloat(), 1f, 10f, { difficulty = it.toInt() }, "$difficulty / 10")
        Spacer(Modifier.height(18.dp))
        DividerLine()
        SectionTitle("SOUND")
        SettingSlider("Alarm volume", volume, 1f, 100f, { volume = it }, "${volume.toInt()}%")
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Alarm", fontSize = 16.sp, color = Ink)
                Text("Save settings and schedule", fontSize = 13.sp, color = Muted)
            }
            Switch(checked = enabled, onCheckedChange = { enabled = it })
        }
        Spacer(Modifier.height(22.dp))
        Button(
            onClick = {
                AlarmPrefs.save(context, hour, minute, volume.toInt(), count, difficulty,
                    shake, math, code, puzzle, enabled)
                if (enabled) {
                    if (Build.VERSION.SDK_INT >= 31 &&
                        !context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
                        context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:${context.packageName}")))
                    } else AlarmScheduler.schedule(context)
                } else AlarmScheduler.cancel(context)
                if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Color.White),
            shape = MaterialTheme.shapes.small
        ) { Text("Save alarm", fontSize = 15.sp) }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onTest, modifier = Modifier.fillMaxWidth().height(48.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Line),
            shape = MaterialTheme.shapes.small) {
            Text("Test alarm", color = Ink)
        }
        Spacer(Modifier.height(28.dp))
        Text("MATH ALARM  ·  VERSION 1.0", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}

@Composable private fun DividerLine() { Spacer(Modifier.fillMaxWidth().height(1.dp).background(Line)) }
@Composable private fun SectionTitle(value: String) {
    Text(value, color = Muted, fontSize = 11.sp, letterSpacing = 1.3.sp,
        modifier = Modifier.padding(top = 20.dp, bottom = 14.dp))
}
@Composable private fun NumberField(value: String, onChange: (String) -> Unit, label: String) {
    Column(Modifier.width(88.dp)) {
        BasicTextField(value, onChange, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(
            color = Ink, fontSize = 22.sp
        ), modifier = Modifier.fillMaxWidth().border(1.dp, Line).padding(12.dp))
        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
    }
}
@Composable private fun CheckRow(label: String, checked: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Ink, fontSize = 15.sp)
        Checkbox(checked, change, colors = CheckboxDefaults.colors(checkedColor = Ink,
            uncheckedColor = Muted, checkmarkColor = Color.White))
    }
}
@Composable private fun SettingSlider(label: String, value: Float, min: Float, max: Float,
                                      change: (Float) -> Unit, valueText: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Ink, fontSize = 14.sp)
            Text(valueText, color = Muted, fontSize = 13.sp)
        }
        Slider(value, change, valueRange = min..max, colors = SliderDefaults.colors(
            thumbColor = Ink, activeTrackColor = Ink, inactiveTrackColor = Line
        ))
    }
}

@Composable
private fun RingingScreen(onDone: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var stage by remember { mutableIntStateOf(0) }
    var answer by remember { mutableStateOf("") }
    var completed by remember { mutableIntStateOf(0) }
    var shakeCount by remember { mutableIntStateOf(0) }
    val tasks = remember {
        val types = mutableListOf<String>()
        if (AlarmPrefs.bool(context, "shake", false)) types.add("shake")
        if (AlarmPrefs.bool(context, "math", true)) types.add("math")
        if (AlarmPrefs.bool(context, "code", false)) types.add("code")
        if (AlarmPrefs.bool(context, "puzzle", false)) types.add("puzzle")
        if (types.isEmpty()) types.add("math")
        val total = AlarmPrefs.int(context, "count", 5).coerceIn(1, 20)
        List(total) { types[it % types.size] }
    }
    val type = tasks[stage.coerceAtMost(tasks.lastIndex)]
    val diff = AlarmPrefs.int(context, "difficulty", 3).coerceIn(1, 10)
    val a = remember(stage) { Random.nextInt(2, 10 + diff * 8) }
    val b = remember(stage) { Random.nextInt(2, 10 + diff * 5) }
    val mathAnswer = a + b
    val codeValue = remember(stage) { (1..(3 + diff / 2)).joinToString("") { Random.nextInt(0, 10).toString() } }
    val sequence = remember(stage) {
        val start = Random.nextInt(1, 10)
        listOf(start, start + 2, start + 4, start + 6)
    }
    val expected = when (type) {
        "math" -> mathAnswer.toString()
        "code" -> codeValue
        "puzzle" -> (sequence.last() + 2).toString()
        else -> ""
    }

    Column(Modifier.fillMaxSize().padding(26.dp), horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.Center) {
        Text("ALARM", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(22.dp))
        Text("Complete the task", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Normal)
        Spacer(Modifier.height(8.dp))
        Text("Task ${stage + 1} of ${tasks.size}", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(42.dp))
        when (type) {
            "shake" -> {
                Text("Shake the phone", color = Ink, fontSize = 22.sp)
                Text("$shakeCount / 20", color = Muted, fontSize = 18.sp, modifier = Modifier.padding(top = 14.dp))
                Text("Motion sensor support is being added in this starter build", color = Muted, fontSize = 12.sp)
                Button(onClick = { shakeCount += 1; if (shakeCount >= 20) { stage++; shakeCount = 0 } },
                    modifier = Modifier.padding(top = 20.dp), colors = ButtonDefaults.buttonColors(containerColor = Ink)) {
                    Text("Count shake", color = Color.White)
                }
            }
            "math" -> {
                Text("$a + $b = ?", color = Ink, fontSize = 32.sp)
                AnswerInput(answer) { answer = it }
            }
            "code" -> {
                Text("Enter this code", color = Ink, fontSize = 18.sp)
                Text(codeValue, color = Ink, fontSize = 34.sp, letterSpacing = 5.sp,
                    modifier = Modifier.padding(vertical = 18.dp))
                AnswerInput(answer) { answer = it }
            }
            else -> {
                Text("Continue the sequence", color = Ink, fontSize = 18.sp)
                Text(sequence.joinToString("   "), color = Ink, fontSize = 27.sp,
                    modifier = Modifier.padding(vertical = 18.dp))
                AnswerInput(answer) { answer = it }
            }
        }
        if (type != "shake") {
            Spacer(Modifier.height(18.dp))
            Button(onClick = {
                if (answer.trim() == expected) {
                    if (stage == tasks.lastIndex) onDone()
                    else { stage++; answer = "" }
                } else answer = ""
            }, modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Ink),
                shape = MaterialTheme.shapes.small) { Text("Submit", color = Color.White) }
        } else if (stage > tasks.lastIndex) onDone()
        Spacer(Modifier.height(30.dp))
        Text("The alarm will stop after all tasks are complete", color = Muted, fontSize = 12.sp)
    }
}

@Composable private fun AnswerInput(value: String, change: (String) -> Unit) {
    BasicTextField(value, change, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(
        color = Ink, fontSize = 20.sp
    ), modifier = Modifier.fillMaxWidth().padding(top = 22.dp).border(1.dp, Line).padding(15.dp))
}
